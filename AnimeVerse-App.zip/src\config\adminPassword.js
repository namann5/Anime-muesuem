// Admin password configuration
// Change this to your desired admin password
export const ADMIN_PASSWORD = "animeverse2024"; // Change this!

// You can also use environment variables in production:
// export const ADMIN_PASSWORD = import.meta.env.VITE_ADMIN_PASSWORD || "animeverse2024";
